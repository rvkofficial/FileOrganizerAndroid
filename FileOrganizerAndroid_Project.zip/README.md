# File Organizer Android

Android Studio starter project recreating the likely core purpose of the uploaded Windows File Organizer app.

## Features
- Android system folder picker (Storage Access Framework; no broad storage permission)
- Counts files in the selected folder
- Organizes common file types into Images, Videos, Audio, PDF, Documents, Spreadsheets, Presentations, Archives and APK folders
- Asks for confirmation before moving files
- Reports moved, skipped and failed counts

## Build APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This is a recreated Android app, not a direct conversion of the Windows EXE.
- File moving depends on the selected storage provider supporting Android's `DocumentsContract.moveDocument`; some providers may reject moves. Test on sample files first.
- Files categorized as Other are intentionally left in place.
