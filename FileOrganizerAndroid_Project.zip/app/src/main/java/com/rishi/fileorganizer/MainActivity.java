package com.rishi.fileorganizer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER = 1001;
    private Uri treeUri;
    private TextView folderText, countText, statusText;
    private Button organizeButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(246, 248, 252));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("File Organizer");
        title.setTextSize(29);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(24, 48, 85));
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Sort files into folders by file type");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.rgb(90, 102, 120));
        LinearLayout.LayoutParams subParams = params();
        subParams.bottomMargin = dp(24);
        page.addView(subtitle, subParams);

        folderText = addText(page, "No folder selected", 16, Color.DKGRAY, true);
        countText = addText(page, "Files found: —", 15, Color.rgb(70, 80, 96), false);
        statusText = addText(page, "Choose a folder to begin. Your files are not uploaded anywhere.", 14, Color.rgb(70, 80, 96), false);

        Button choose = new Button(this);
        choose.setText("Choose folder");
        page.addView(choose, buttonParams());
        choose.setOnClickListener(v -> chooseFolder());

        organizeButton = new Button(this);
        organizeButton.setText("Organize files");
        organizeButton.setEnabled(false);
        page.addView(organizeButton, buttonParams());
        organizeButton.setOnClickListener(v -> confirmOrganize());

        TextView note = new TextView(this);
        note.setText("Files are moved into subfolders such as PDF, Images, Videos, Audio, Documents and Other. Existing files with the same name are left untouched.");
        note.setTextSize(13);
        note.setTextColor(Color.rgb(95, 104, 120));
        LinearLayout.LayoutParams noteParams = params();
        noteParams.topMargin = dp(18);
        page.addView(note, noteParams);

        setContentView(scroll);
    }

    private TextView addText(LinearLayout parent, String text, int size, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams p = params();
        p.bottomMargin = dp(14);
        parent.addView(tv, p);
        return tv;
    }

    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = params();
        p.topMargin = dp(8);
        p.bottomMargin = dp(8);
        return p;
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FOLDER);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            treeUri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(treeUri, flags);
            String name = getFolderName(treeUri);
            folderText.setText("Selected folder: " + name);
            int count = countFiles(treeUri);
            countText.setText("Files found: " + count);
            statusText.setText("Folder selected. Review the folder before organizing.");
            organizeButton.setEnabled(true);
        }
    }

    private String getFolderName(Uri uri) {
        String docId = DocumentsContract.getTreeDocumentId(uri);
        int slash = docId.lastIndexOf(':');
        String part = slash >= 0 ? docId.substring(slash + 1) : docId;
        if (part.isEmpty()) return "Selected folder";
        int last = part.lastIndexOf('/');
        return last >= 0 ? part.substring(last + 1) : part;
    }

    private int countFiles(Uri tree) {
        int count = 0;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        try (Cursor c = getContentResolver().query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_MIME_TYPE},
                null, null, null)) {
            if (c != null) while (c.moveToNext()) {
                String mime = c.getString(1);
                if (!DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) count++;
            }
        } catch (Exception ignored) {}
        return count;
    }

    private void confirmOrganize() {
        new AlertDialog.Builder(this)
            .setTitle("Organize this folder?")
            .setMessage("Files will be moved into type-based subfolders. This changes their locations. Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Organize", (d, w) -> organizeFiles())
            .show();
    }

    private void organizeFiles() {
        if (treeUri == null) return;
        ContentResolver resolver = getContentResolver();
        int moved = 0, skipped = 0, failed = 0;
        String rootId = DocumentsContract.getTreeDocumentId(treeUri);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId);
        try (Cursor c = resolver.query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                             DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                             DocumentsContract.Document.COLUMN_MIME_TYPE},
                null, null, null)) {
            if (c == null) throw new IllegalStateException("Could not read this folder.");
            while (c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime) || name == null) continue;
                String category = categoryFor(name, mime);
                if ("Other".equals(category)) { skipped++; continue; }

                try {
                    Uri source = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                    Uri targetDir = findOrCreateFolder(treeUri, rootId, category);
                    if (targetDir == null) { failed++; continue; }
                    // DocumentFile is intentionally avoided to keep this project dependency-free.
                    String targetParentId = DocumentsContract.getDocumentId(targetDir);
                    DocumentsContract.moveDocument(resolver, source,
                            DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId),
                            DocumentsContract.buildDocumentUriUsingTree(treeUri, targetParentId));
                    moved++;
                } catch (Exception ex) {
                    failed++;
                }
            }
        } catch (Exception e) {
            statusText.setText("Could not organize this folder: " + e.getMessage());
            return;
        }
        countText.setText("Files remaining in root: " + countFiles(treeUri));
        statusText.setText("Finished. Moved: " + moved + " · Skipped: " + skipped + " · Failed: " + failed);
        Toast.makeText(this, "Organization finished", Toast.LENGTH_SHORT).show();
    }

    private Uri findOrCreateFolder(Uri tree, String rootId, String folderName) throws Exception {
        ContentResolver resolver = getContentResolver();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
        try (Cursor c = resolver.query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                             DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                             DocumentsContract.Document.COLUMN_MIME_TYPE},
                null, null, null)) {
            if (c != null) while (c.moveToNext()) {
                if (folderName.equals(c.getString(1)) &&
                    DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2))) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
                }
            }
        }
        return DocumentsContract.createDocument(resolver,
                DocumentsContract.buildDocumentUriUsingTree(tree, rootId),
                DocumentsContract.Document.MIME_TYPE_DIR, folderName);
    }

    private String categoryFor(String name, String mime) {
        String n = name.toLowerCase(Locale.ROOT);
        String ext = "";
        int dot = n.lastIndexOf('.');
        if (dot >= 0 && dot < n.length() - 1) ext = n.substring(dot + 1);
        if (mime != null && mime.startsWith("image/") ||
                matches(ext, "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg")) return "Images";
        if (mime != null && mime.startsWith("video/") ||
                matches(ext, "mp4", "mkv", "mov", "avi", "webm", "3gp")) return "Videos";
        if (mime != null && mime.startsWith("audio/") ||
                matches(ext, "mp3", "wav", "aac", "ogg", "m4a", "flac")) return "Audio";
        if (matches(ext, "pdf")) return "PDF";
        if (matches(ext, "doc", "docx", "odt", "rtf", "txt", "md")) return "Documents";
        if (matches(ext, "xls", "xlsx", "csv", "ods")) return "Spreadsheets";
        if (matches(ext, "ppt", "pptx", "odp")) return "Presentations";
        if (matches(ext, "zip", "rar", "7z", "tar", "gz")) return "Archives";
        if (matches(ext, "apk")) return "APK";
        return "Other";
    }

    private boolean matches(String value, String... options) {
        for (String option : options) if (option.equals(value)) return true;
        return false;
    }
}
